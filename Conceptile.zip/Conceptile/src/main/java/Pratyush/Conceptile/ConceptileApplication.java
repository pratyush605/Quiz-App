package Pratyush.Conceptile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConceptileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConceptileApplication.class, args);
	}

}
