package Pratyush.Conceptile;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConceptileApplicationTests {

	@Test
	void contextLoads() {
	}

}
